const myButton = document.getElementById("myButton");
myButton.onclick = function() {
    
}